struct SnackResponse: Codable {
    let marca: String
    let empresa: String
    let ruc: String
    let correo: String
    let logo: String
}
