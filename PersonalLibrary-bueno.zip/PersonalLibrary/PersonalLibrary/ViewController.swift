//
//  ViewController.swift
//  PersonalLibrary
//
//  Created by DISEÑO on 6/12/24.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()

        // Crear el gradiente
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = view.bounds
        
        // Definir los colores del gradiente (de más oscuro a más claro)
        gradientLayer.colors = [
            UIColor(red: 0xFB / 255.0, green: 0xE4 / 255.0, blue: 0xD8 / 255.0, alpha: 1.0).cgColor,
            UIColor(red: 0xDF / 255.0, green: 0xB6 / 255.0, blue: 0xB2 / 255.0, alpha: 1.0).cgColor,
            UIColor(red: 0x52 / 255.0, green: 0x2B / 255.0, blue: 0x5B / 255.0, alpha: 1.0).cgColor,
            UIColor(red: 0x2B / 255.0, green: 0x12 / 255.0, blue: 0x4C / 255.0, alpha: 1.0).cgColor 
        ]
        
        // Establecer la dirección del gradiente (arriba -> abajo)
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1)
        
        // Agregar el gradiente a la vista principal
        view.layer.insertSublayer(gradientLayer, at: 0)
    }
}
