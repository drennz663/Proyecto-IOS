//
//  ProductTableViewCell.swift
//  PersonalLibrary
//
//  Created by DISEÑO on 12/12/24.
//

import UIKit

class ProductTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var descriptionsLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var medidaLabel: UILabel!
    
    var product: Product?
    var viewController: UIViewController?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureProduct(product: Product, viewController: UIViewController) {
        self.nameLabel.text = "Nombre: \(product.name ?? "")"
        self.idLabel.text = "ID: \(product.id ?? "")"
        self.descriptionsLabel.text = "Descripción: \(product.description)"
        self.priceLabel.text = "Precio: \(product.price)"
        self.medidaLabel.text = "Medida: \(product.medida ?? "")"
        
        self.product = product
        self.viewController = viewController
    }
}
