import UIKit
import CoreData

class EditProductViewController: UIViewController {
    
    @IBOutlet weak var idEditTextField: UITextField!
    @IBOutlet weak var nameEditTextField: UITextField!
    @IBOutlet weak var descriptionsEditTextField: UITextField!
    @IBOutlet weak var priceEditTextField: UITextField!
    @IBOutlet weak var medidaEditPickerView: UIPickerView!
    
    var producUpdate: Product?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTextFields()
    }
    
    func connectBD() -> NSManagedObjectContext {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        return delegate.persistentContainer.viewContext
    }
    
    func configureTextFields() {
        idEditTextField.text = producUpdate?.id
        nameEditTextField.text = producUpdate?.name
        descriptionsEditTextField.text = producUpdate?.description
        priceEditTextField.text = String(producUpdate?.price ?? 0.0)
    }
    
    func updateProduct() {
        let context = connectBD()
        
        if let product = producUpdate {
            product.setValue(nameEditTextField.text, forKey: "name")
            product.setValue(descriptionsEditTextField.text, forKey: "description")
            
            if let priceText = priceEditTextField.text, let price = Float(priceText) {
                product.setValue(price, forKey: "price")
            }
            let selectedMedida = medidaEditPickerView.selectedRow(inComponent: 0)
            let medida = String(selectedMedida) 
            
            product.setValue(medida, forKey: "medida")
            
            do {
                try context.save()
                navigationController?.popViewController(animated: true)
                print("Producto actualizado correctamente")
            } catch let error as NSError {
                print("Error al actualizar el producto: \(error.localizedDescription)")
            }
        }
    }


    @IBAction func actualizarButton(_ sender: UIButton) {
        updateProduct()
    }
}
