import UIKit
import CoreData

class ListProductViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    
    @IBOutlet weak var listProductTableView: UITableView!
    
    var productData = [Product]()

    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView()
        fetchProductList()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        fetchProductList()
        listProductTableView.reloadData()
    }

    func connectBD() -> NSManagedObjectContext {
        let delegate = UIApplication.shared.delegate as! AppDelegate
        return delegate.persistentContainer.viewContext
    }

    func configureTableView() {
        listProductTableView.delegate = self
        listProductTableView.dataSource = self
        listProductTableView.rowHeight = 280
    }

    func fetchProductList() {
        let context = connectBD()
        let fetchRequest: NSFetchRequest<Product> = Product.fetchRequest()
        do {
            productData = try context.fetch(fetchRequest)
        } catch let error as NSError {
            print("Error al obtener los productos: \(error.localizedDescription)")
        }
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return productData.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductTableViewCell", for: indexPath) as! ProductTableViewCell
        let product = productData[indexPath.row]
        cell.configureProduct(product: product, viewController: self)
        return cell
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let context = connectBD()
            let product = productData[indexPath.row]
            context.delete(product)

            do {
                try context.save()
                productData.remove(at: indexPath.row)
                tableView.deleteRows(at: [indexPath], with: .automatic)
            } catch let error as NSError {
                print("Error al eliminar el producto: \(error.localizedDescription)")
            }
        }
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "editProductSegue", sender: self)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "updateView" {
            if let indexPath = listProductTableView.indexPathForSelectedRow {
                let selectedProduct = productData[indexPath.row]
                let editProductViewController = segue.destination as! EditProductViewController
                editProductViewController.producUpdate = selectedProduct
            }
        }
    }

}
