//
//  Model.swift
//  servicioRest
//
//  Created by DAMII on 14/12/24.
//

import Foundation

struct RecipeResponse: Codable {
    //creamos las constantes y su tipo de datos
    let recipeName: String
    let description: String
    let urlPhoto: String
    let countryOrigin: String
    let address: String
    let rating: Int
    let latitude: Double
    let longitude: Double
    let preparationTime: String
    let ingredients: [String]
}
