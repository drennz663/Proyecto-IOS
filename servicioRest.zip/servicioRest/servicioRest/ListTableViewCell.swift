//
//  ListTableViewCell.swift
//  servicioRest
//
//  Created by DAMII on 14/12/24.
//

import UIKit
import AlamofireImage

class ListTableViewCell: UITableViewCell {

    @IBOutlet weak var imgImagen: UIImageView!
    @IBOutlet weak var labelLabel: UILabel!
    @IBOutlet weak var generalView: UIView!
    
    override func awakeFromNib() {
            super.awakeFromNib()
            selectionStyle = .none
            layer.cornerRadius = 10
            backgroundColor = UIColor.clear
        }

        override func setSelected(_ selected: Bool, animated: Bool) {
            super.setSelected(selected, animated: animated)
        }
        
        func configureView(viewList: RecipeResponse?) {
            guard let list = viewList else { return }
            labelLabel.text = list.recipeName
            let urlPhotoRecipe = list.urlPhoto
            if let url = URL(string: urlPhotoRecipe) {
                imgImagen?.af.setImage(withURL: url, placeholderImage:  UIImage(named: "icon"))
            }
            imgImagen?.contentMode = .scaleAspectFill
            imgImagen?.layer.cornerRadius = 10
            generalView?.layer.shadowOffset = CGSize.zero
            generalView?.layer.shadowRadius = 1
            generalView?.layer.shadowOpacity = 1
            generalView?.layer.cornerRadius = 40
        }
    
}
