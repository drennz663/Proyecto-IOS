//
//  DetalleViewController.swift
//  servicioRest
//
//  Created by DAMII on 14/12/24.
//

import UIKit
import AlamofireImage

class DetalleViewController: UIViewController {
    
    @IBOutlet weak var imgDetalle: UIImageView!
    @IBOutlet weak var label1: UILabel!
    @IBOutlet weak var label2: UILabel!
    
    var recipeDetail: RecipeResponse?
    
    override func viewDidLoad() {
       
        
        super.viewDidLoad()
        if recipeDetail != nil{
            label1.text = recipeDetail?.recipeName
            label2.text = recipeDetail?.countryOrigin
            
            if let url = URL(string: recipeDetail?.urlPhoto ?? ""){
                imgDetalle?.af.setImage(withURL: url)
                imgDetalle?.contentMode = .scaleToFill
                imgDetalle?.layer.shadowOffset = CGSize.zero
                imgDetalle?.layer.shadowRadius = 1
                imgDetalle?.layer.shadowOpacity = 1
                imgDetalle?.layer.cornerRadius = 30

            }
        }
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func didTapButton(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
