//
//  ViewController.swift
//  servicioRest
//
//  Created by DAMII on 14/12/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tvTabla: UITableView!
    var arrayRecipe = [RecipeResponse]()
    var listReciepeSelect: RecipeResponse?

    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureTableView() //llamamos a la función de la configuración de la tabla
        fetchData()
        // Do any additional setup after loading the view.
    }

    //configuramos la tabla
    func configureTableView() {
        tvTabla.delegate = self
        tvTabla.dataSource = self
        tvTabla.register(UINib(nibName: "ListTableViewCell", bundle: nil), forCellReuseIdentifier: "ListTableViewCell")
        tvTabla.rowHeight = 240
        tvTabla.showsVerticalScrollIndicator = false
        tvTabla.separatorStyle = .none
    }
    
    //función para listar a la lista
    func fetchData() {
        let webService = "http://demo6693165.mockable.io/getRecipes"
        guard let url = URL(string: webService) else {
            return
        }

        URLSession.shared.dataTask(with: url) { [weak self] (data, response, error) in
            guard let response = response as? HTTPURLResponse, 200 ... 299  ~= response.statusCode else {
                print("Error general: \(String(describing: error?.localizedDescription))")
                return
            }
            
            do {
                guard let dataJSON = data else {
                    return
                }
  
                self?.arrayRecipe = try JSONDecoder().decode([RecipeResponse].self, from: dataJSON)

                DispatchQueue.main.async {
                    self?.tvTabla.reloadData()
                }
            } catch {
                print("Error al parsear datos")
            }
            
        }.resume()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayRecipe.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tvTabla.dequeueReusableCell(withIdentifier: "ListTableViewCell", for: indexPath) as? ListTableViewCell
        let list = arrayRecipe[indexPath.row]
        cell?.configureView(viewList: list)
        return cell ?? UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        listReciepeSelect = arrayRecipe[indexPath.row]
        let storyBoardMain = UIStoryboard(name: "Main", bundle: nil)
        let viewController = storyBoardMain.instantiateViewController(withIdentifier: "DetalleViewController") as? DetalleViewController
        viewController?.recipeDetail = listReciepeSelect
        
        self.navigationController?.pushViewController(viewController ?? ViewController(), animated: true)
        
    }
}

