//
//  bebidaViewController.swift
//  MiniMarketJuancito
//
//  Created by DAMII on 19/12/24.
//

import UIKit

class bebidaViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    
    
}
